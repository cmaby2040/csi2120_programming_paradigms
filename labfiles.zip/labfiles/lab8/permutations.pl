color(red).
color(green).
color(blue).


% setof([R,G,B],(color(R),color(G),color(B)),L).
