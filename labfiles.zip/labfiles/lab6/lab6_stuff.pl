
countDown(N):- repeat, N<0, writeln(N1), N1 is N-1, !.

/*
countDown(N):- repeat, writeln(N1), N1 is N-1, N<0, !.
*/
