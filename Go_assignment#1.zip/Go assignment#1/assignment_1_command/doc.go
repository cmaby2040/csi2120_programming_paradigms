// assignment_1_command project doc.go

/*
assignment_1_command document
*/
package main
