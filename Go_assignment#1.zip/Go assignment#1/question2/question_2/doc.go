// question_2 project doc.go

/*
question_2 document
*/
package main
