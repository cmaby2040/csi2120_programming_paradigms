// question3 project doc.go

/*
question3 document
*/
package main
